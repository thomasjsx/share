Stitches Kaprow — F6.1 Package (Adobe Premiere)
============================================================

Event: 05-29-f6_1-a7a030

Flow: F6.1 — N-clip auto-cut → Premiere
The timeline.xml ships as a pre-cut sequence with one
clip per suggested cut + markers explaining why each cut
was picked ("loud audio" / "motion" / "person framed").
Refine the cuts in Premiere, then export.


You are holding a self-contained editing package for Adobe Premiere
Pro. Inside:

  clips/                — the aligned, normalized clips
  manifest.json         — event metadata (machine-readable)
  cuts_suggested.json   — the engine's auto-suggested cut points
  timeline.xml          — pre-built timeline (uses path placeholders)
  import.command        — macOS launcher: resolves paths + opens Premiere
  README.txt            — this file
  upload.webloc         — double-click on macOS to open the upload page

Timeline (offset = position on the shared event clock):
  clip_01.mp4   offset +0.00s   length 12.97s   sync conf 1.00
  clip_02.mp4   offset +1.00s   length 11.45s   sync conf 1.00

How to edit — fast path (recommended, macOS + Premiere)
-------------------------------------------------------
  1. Double-click import.command.
     It rewrites timeline.xml with absolute file paths and opens
     Adobe Premiere Pro. It also reveals timeline_resolved.xml in
     the Finder so you can drag it into Premiere if needed.

  2. In Premiere:
     File → Import → select timeline_resolved.xml → Open
     Premiere builds the sequence in the Project panel. Double-click
     it to open in the Timeline.

  3. Cut and refine.

  4. Export 1080x1920 portrait MP4 (H.264, AAC audio).
     File → Export → Media → preset "Match Source - Adaptive High
     Bitrate" with resolution 1080x1920 works fine.

How to edit — DaVinci Resolve / FCP fallback
--------------------------------------------
  This package is for Premiere. For FCP, request the F4 package
  (timeline.fcpxml instead of timeline.xml).

How to edit — manual path (any NLE)
-----------------------------------
  1. Ignore timeline.xml entirely.
  2. Drag the clips/ folder into your NLE.
  3. Position each clip at its offset above.
  4. Cut between cameras to make the remix.
  5. Export 1080x1920 portrait MP4.

How to upload
-------------
  Open this URL (or double-click upload.webloc):

    http://web-production-1cf38.up.railway.app/api/f6/upload/05-29-f6_1-a7a030?token=c43681c106e34d8592a250859076a7d5

  Drag your finished MP4 onto the page. Stitches will fan out the
  remix as individual iMessages to every contributor automatically.

Token note
----------
The URL above includes a one-time-ish upload token specific to this
package. Don't share the URL — anyone with it can upload to this
event. The token is bound to event_id=05-29-f6_1-a7a030.
