#!/usr/bin/env bash
# Stitches F6 — open timeline.xml in Adobe Premiere Pro with paths
# resolved to the unzipped folder location.
#
# Usage: double-click this file in the Finder after unzipping the
# Stitches package. If macOS Gatekeeper blocks the first run,
# right-click → Open → confirm.

set -e
SELF_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SELF_DIR"

if [[ ! -f timeline.xml ]]; then
    echo "ERROR: timeline.xml not found in $SELF_DIR"
    echo "Did you unzip the package fully?"
    read -n 1 -s -r -p "Press any key to exit..."
    exit 1
fi

# Rewrite path placeholder to absolute
sed "s|__STITCHES_BASE__|${SELF_DIR}|g" timeline.xml > timeline_resolved.xml
echo "Wrote timeline_resolved.xml (paths resolved to $SELF_DIR)"

# Try to find Premiere — version-suffixed app bundle is common.
# Adobe releases yearly; we check the most recent versions first.
PREMIERE=""
for candidate in \
    "/Applications/Adobe Premiere Pro 2026/Adobe Premiere Pro 2026.app" \
    "/Applications/Adobe Premiere Pro 2025/Adobe Premiere Pro 2025.app" \
    "/Applications/Adobe Premiere Pro 2024/Adobe Premiere Pro 2024.app" \
    "/Applications/Adobe Premiere Pro 2023/Adobe Premiere Pro 2023.app" \
    "/Applications/Adobe Premiere Pro.app"; do
    if [[ -d "$candidate" ]]; then
        PREMIERE="$candidate"
        break
    fi
done

# Fallback — glob any Adobe Premiere Pro YYYY directory we haven't
# hardcoded (catches future versions without a script update).
if [[ -z "$PREMIERE" ]]; then
    for candidate in /Applications/Adobe\ Premiere\ Pro\ */Adobe\ Premiere\ Pro\ *.app; do
        if [[ -d "$candidate" ]]; then
            PREMIERE="$candidate"
            break
        fi
    done
fi

if [[ -z "$PREMIERE" ]]; then
    echo ""
    echo "Premiere not found in /Applications. Open timeline_resolved.xml"
    echo "manually via File → Import in Premiere."
    open -R "$SELF_DIR/timeline_resolved.xml"
    exit 0
fi

echo "Opening Premiere: $PREMIERE"
# Premiere doesn't auto-import XMEML on `open` — it opens the file as
# a project doc which fails. So we open Premiere and the operator
# does File → Import → timeline_resolved.xml. Reveal the file in
# Finder so they can drag it in.
open -a "$PREMIERE"
open -R "$SELF_DIR/timeline_resolved.xml"

echo "Premiere launched. In Premiere: File → Import → timeline_resolved.xml"
